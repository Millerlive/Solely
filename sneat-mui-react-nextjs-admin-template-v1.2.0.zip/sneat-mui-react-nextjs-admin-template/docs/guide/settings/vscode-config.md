# VSCode Configurations

If a user is using VSCode editor, then the user should not have any issues related to any extensions and plugins that we provide in the downloadable package.

We provide `.vscode` folder in the root directory of the downloadable package. In this folder, we provide all the extensions and settings that are necessary for your project to run smoothly.

The user need to install all the recommended extensions that are suggested by the VSCode editor. After all the installations are done, reload or close & reopen your VSCode editor.
