---
sidebarDepth: 0
---

# How to integrate this template into my existing project ?

Since this is a template and a starter project, it’s built as the starting point of your project. It cannot be simply installed and used with an existing project like a third party library.

Although using our template with any existing project is still possible, it would require extra effort to connect everything together. We strongly recommend you to either start your project with Sneat, or move your project on top of it to have the best experience.
