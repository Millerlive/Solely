---
sidebarDepth: 0
---

# How to enable / disable responsive font ?

We have enabled the responsive fonts by default. If a user wants to disable the responsive fonts, then go to the `src/configs/themeConfig.ts` file and change the value of the `responsiveFontSizes` property to `false`. The user may go to the [ThemeConfig](/guide/settings/theme-config.html) docs to look at the other properties.
