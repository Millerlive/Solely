---
sidebarDepth: 0
---

# How to change Direction ?

Great thing is our template comes with RTL(Right to Left) support.

There can be two possibilities,

If you want to set default direction to RTL Please refer our configuration docs and set `direction` value from `ltr` to `rtl`

[Theme Configuration Doc](/guide/settings/theme-config.html)

And, in case you want to implement toggle button functionality which can toggle direction, refer below doc:

[Toggle Direction Doc](/guide/development/rtl.html)
