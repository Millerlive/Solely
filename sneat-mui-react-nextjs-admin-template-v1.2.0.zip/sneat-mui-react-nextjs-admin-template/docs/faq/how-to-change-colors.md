---
sidebarDepth: 0
---

# How to change colors ?

Most of the time very first question to start any project would be to setup project colors. In this case please refer [how to change colors](/guide/development/theming.html#how-to-override-color-palette) doc.

You should easily be able to override any colors like primary, secondary, info, warning, success, error or any other.

Also consider reading official MUI docs on [how to customize MUI palette documentation](https://mui.com/material-ui/customization/palette/) for detailed understanding.
