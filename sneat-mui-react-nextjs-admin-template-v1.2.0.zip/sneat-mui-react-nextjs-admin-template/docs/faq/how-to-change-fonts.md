---
sidebarDepth: 0
---

# How to change fonts / typography ?

In case you want to add new fonts or change the current font or use multiple fonts, Please refer following doc:

[How to Add / Change fonts](/guide/development/theming.html#how-to-override-typography)