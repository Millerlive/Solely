---
sidebarDepth: 0
---

# How to remove Auth from the project

Authentication (Auth) is used to check whether a user is logged in or not.

Authentication is implemented in both `full-version` and `starter-kit` versions.

Please refer to [this](/guide/development/authentication.html#how-to-remove-authentication) docs if a user wants to remove Authentication completely from the project.
