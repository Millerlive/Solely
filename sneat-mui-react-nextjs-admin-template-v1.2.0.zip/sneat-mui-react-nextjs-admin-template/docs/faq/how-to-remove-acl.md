---
sidebarDepth: 0
---

# How to remove ACL from the project

Access Control (ACL) is used to define which users have access to which pages/sections.

ACL is implemented in both `full-version` and `starter-kit` versions.

Please refer to [this](/guide/development/access-control.html#how-to-remove-acl) docs if a user wants to remove ACL completely from the project.
