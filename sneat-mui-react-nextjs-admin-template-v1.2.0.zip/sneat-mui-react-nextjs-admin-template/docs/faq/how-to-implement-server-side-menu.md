---
sidebarDepth: 0
---

# How to implement server-side menu ?

If a user wants to render a server-side menu in the Vertical menu, please refer to [this](/guide/layout/navigation-menu-server-side.html#vertical-layout) docs.

If a user wants to render a server-side menu in the Horizontal menu, please refer to [this](/guide/layout/navigation-menu-server-side.html#horizontal-layout) docs.
