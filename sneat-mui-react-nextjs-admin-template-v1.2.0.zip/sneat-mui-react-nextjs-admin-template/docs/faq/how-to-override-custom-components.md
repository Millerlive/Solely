---
sidebarDepth: 0
---

# How to override custom components ?

If a user wants to override the custom components that we provide in the `src/@core/components` folder, then please refer to [this](/guide/components/override-components.html) docs.
