---
sidebarDepth: 0
---

# How to change Skin ?

We provide `default` skin as the default skin. If a user wants to change the default skin, then go to the `src/configs/themeConfig.ts` file and change the value of the `skin` property as per your project requirements. The user may go to the [ThemeConfig](/guide/settings/theme-config.html) docs to see the options available in `skin` as well as for other properties.

If a user wants to style something according to the skins, the user can read the current skin in [this](/guide/settings/hooks.html#read-values-from-settings-context) doc.
