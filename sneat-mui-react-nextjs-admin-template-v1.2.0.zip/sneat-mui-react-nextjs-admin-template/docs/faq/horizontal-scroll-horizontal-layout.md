---
sidebarDepth: 0
---

# Horizontal scrollbar in Horizontal layout

You might get a horizontal scrollbar in the horizontal layout. This is because we have given the feature of animation on the open and close of the horizontal navigation group.

If you are facing the problem of the horizontal scrollbar and you do not want an animation in the horizontal navigation menu, then change the value of the `horizontalMenuAnimation` property to `false` in the `src/configs/themeConfig.ts` file.
